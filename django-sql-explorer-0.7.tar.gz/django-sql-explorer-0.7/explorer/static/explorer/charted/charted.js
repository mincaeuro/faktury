/*global $, PageController */

$(function () {
  var pageController = new PageController()

  pageController.setupPage({dataUrl: dataUrl })

})
